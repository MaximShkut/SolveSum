//
//  SolveSumApp.swift
//  SolveSum
//
//  Created by user236450 on 6/4/23.
//

import SwiftUI

@main
struct SolveSumApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
